<!DOCTYPE html>
<html>
<head>
    <title>Consultas</title>
</head>
<body>
    <h2>Consulta de Citas Médicas</h2>

    <form method="GET" action="consultar_citas.php">
        <label>Fecha:</label>
        <input type="date" name="fecha" required>
        <input type="submit" value="Consultar">
    </form>

    <h3>Resultados:</h3>
    <table>
        <thead>
            <tr>
                <th>ID cita</th>
                <th>Fecha</th>
                <th>Paciente</th>
                <th>Médico</th>
            </tr>
        </thead>
        <tbody>

        </tbody>
    </table>
</body>
</html>
